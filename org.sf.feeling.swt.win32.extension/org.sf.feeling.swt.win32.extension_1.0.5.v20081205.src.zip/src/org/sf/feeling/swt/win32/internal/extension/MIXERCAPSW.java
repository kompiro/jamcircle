package org.sf.feeling.swt.win32.internal.extension;

public class MIXERCAPSW extends MIXERCAPS
{

	private static final long serialVersionUID = 3144954699826156088L;

	public char[] szPname = new char[Extension.MAX_PATH];

	public static int sizeof = 540;
}
