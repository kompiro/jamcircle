package org.sf.feeling.swt.win32.internal.extension;

public class MIXERCAPSA extends MIXERCAPS
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4401269731338510700L;

	public byte[] szPname = new byte[Extension.MAX_PATH];

	public static int sizeof = 280;
}
