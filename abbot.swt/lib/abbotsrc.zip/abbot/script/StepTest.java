package abbot.script;

import junit.extensions.abbot.TestHelper;

public class StepTest extends junit.framework.TestCase {

    public void testStub() {
    }

    public StepTest(String name) { super(name); }

    public static void main(String[] args) {
        TestHelper.runTests(args, StepTest.class);
    }
}
