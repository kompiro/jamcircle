package abbot.editor.recorder;

import java.awt.*;
import java.awt.event.InputEvent;
import javax.swing.*;

import junit.extensions.abbot.RepeatHelper;
import abbot.script.Resolver;
import abbot.tester.*;

/**
 * Unit test to verify proper capture of user semantic events on a JTree.
 */
public class JTreeRecorderTest 
    extends AbstractSemanticRecorderFixture {

    private JTreeTester tester;
    private JTree tree;

    protected SemanticRecorder createSemanticRecorder(Resolver r) {
        return new JTreeRecorder(r);
    }

    public void testCaptureRowSelection() {
        startRecording();
        tester.actionSelectRow(tree, 1);
        assertStep("SelectRow\\(.*\"\\[JTree, colors\\]\"\\)");
    }

    public void testCaptureRowSelectionHiddenRoot() {
        tree.setRootVisible(false);
        startRecording();
        tester.actionSelectRow(tree, 1);
        assertStep("SelectRow\\(.*\"\\[sports\\]\"\\)");
    }

    public void testCaptureMultipleClick() {
        startRecording();
        int row = 2;
        tester.actionClick(tree, new JTreeLocation(row),
                           InputEvent.BUTTON1_MASK, 2);
        assertStep("Click\\(.*,\"\\[JTree, sports\\]\",BUTTON1_MASK,2\\)");
    }

    public void testCaptureToggleRow() {
        startRecording();
        int row = 2;
        Rectangle bounds = new JTreeLocation(row).getBounds(tree);
        // Make a reasonable guess of the proper location.
        Point pt = new Point(bounds.x - bounds.height/2,
                             bounds.y + bounds.height/2);
        tester.actionClick(tree, pt.x, pt.y);
        assertStep("ToggleRow\\(.*,\"\\[JTree, sports\\]\"\\)");
    }

    public void testCapturePopup() {
        final String NAME = "item 1";
        JPopupMenu menu = new JPopupMenu();
        menu.add(new JMenuItem(NAME));
        addPopup(tree, menu);
        startRecording();
        tester.actionSelectPopupMenuItem(tree, 0, 0, NAME);
        assertStep("SelectPopupMenuItem\\(.*,\"\\[JTree\\]\","
                   + NAME + "\\)");
    }

    protected void setUp() {
        tree = new JTree();
        tester = (JTreeTester)ComponentTester.getTester(tree);
        showFrame(tree);
    }

    public JTreeRecorderTest(String name) {
        super(name);
    }

    public static void main(String[] args) {
        RepeatHelper.runTests(args, JTreeRecorderTest.class);
    }
}
