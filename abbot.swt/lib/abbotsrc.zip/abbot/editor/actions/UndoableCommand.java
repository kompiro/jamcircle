package abbot.editor.actions;

public interface UndoableCommand extends Command, Undoable {
}

