package abbot.tester;

import java.awt.*;
import javax.swing.*;
import javax.swing.tree.*;

import junit.extensions.abbot.*;

/** Unit test to verify the JTreeTester class.<p> */
// TODO add test for lazy-loading children, i.e. load on node select
public class JTreeTesterTest extends ComponentTestFixture {

    private JTreeTester tester;
    private JTree tree;
    private JScrollPane scrollPane;

    protected void setUp() {
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("root");
        DefaultMutableTreeNode parent, child, leaf;
        int COUNT = 5;
        for (int i=0;i < COUNT;i++) {
            parent = new DefaultMutableTreeNode("parent " + i);
            root.add(parent);
            for (int j=0;j < COUNT;j++) {
                child = new DefaultMutableTreeNode("child " + j);
                parent.add(child);
                for (int k=0;k < COUNT;k++) {
                    leaf = new DefaultMutableTreeNode("leaf " + k, false);
                    child.add(leaf);
                }
            }
        }
        tree = new JTree(root);
        scrollPane = new JScrollPane(tree);
        tester = new JTreeTester();
    }

    public void testFindPathForStringPath() {
        TreePath stringPath = new TreePath(new String[] {
            "root", "parent 2", "child 2"
        });
        TreePath path = JTreeLocation.findMatchingPath(tree, stringPath);
        assertNotNull("Couldn't convert path", path);
        assertEquals("Wrong path",
                     "[root, parent 2, child 2]", path.toString());
    }

    // FIXME sporadic linux (1.4.2) failures
    public void testMakeVisibleWithStringPath() {
        showFrame(scrollPane);
        TreePath stringPath = new TreePath(new String[] {
            "root", "parent 4", "child 3"
        });
        tester.actionMakeVisible(tree, stringPath);
        TreePath path = JTreeLocation.findMatchingPath(tree, stringPath);
        assertTrue("Path not visible", tree.isVisible(path));
    }

    public void testMakeVisibleWithRealPath() {
        TreePath stringPath = new TreePath(new String[] {
            "root", "parent 4", "child 3", "leaf 1"
        });
        TreePath path = JTreeLocation.findMatchingPath(tree, stringPath);
        tester.actionMakeVisible(tree, path);
        assertTrue("Path not visible", tree.isVisible(path));
    }

    public void testMakeVisibleWithHiddenRoot() {
        tree.setRootVisible(false);
        tester.actionWaitForIdle();
        TreePath stringPath = new TreePath(new String[] {
            "parent 2", "child 1", "leaf 2"
        });
        TreePath path = JTreeLocation.findMatchingPath(tree, stringPath);
        tester.actionMakeVisible(tree, path);
        assertTrue("Path not visible", tree.isVisible(path));
    }

    public void testMakeVisibleMissingPath() {
        showFrame(scrollPane);
        TreePath stringPath = new TreePath(new String[] {
            "root", "parent 4", "child x"
        });
        try {
            tester.actionMakeVisible(tree, stringPath);
            fail("Should throw an exception when path doesn't match");
        }
        catch(LocationUnavailableException e) {
        }
    }

    public void testSelectPath() {
        showFrame(scrollPane);
        // Select using tree location path
        TreePath stringPath = new TreePath(new String[] {
            "root", "parent 2", "child 2" 
        });
        TreePath path = JTreeLocation.findMatchingPath(tree, stringPath);
        assertNotNull("Couldn't convert path", path);

        tester.actionSelectRow(tree, new JTreeLocation(stringPath));
        TreePath[] paths = tree.getSelectionPaths();
        assertTrue("Paths not visible", tree.isVisible(path));
        assertTrue("No paths selected", paths != null);
        assertEquals("Too many selected", 1, paths.length);
        assertEquals("Wrong path selected", stringPath.toString(), paths[0].toString());
    }

    public void testSelectPathHiddenRoot() {
        showFrame(scrollPane);
        // root is optional if it is hidden
        TreePath stringPath = new TreePath(new String[] {
            "root", "parent 2", "child 2" 
        });
        TreePath stringPath2 = new TreePath(new String[] {
            "parent 2", "child 1" 
        });
        tree.setRootVisible(false);
        TreePath path = JTreeLocation.findMatchingPath(tree, stringPath);
        assertNotNull("Couldn't convert path", path);

        tester.actionSelectRow(tree, new JTreeLocation(stringPath));
        TreePath[] paths = tree.getSelectionPaths();
        assertTrue("Paths not visible", tree.isVisible(path));
        assertTrue("No paths selected", paths != null);
        assertEquals("Too many selected", 1, paths.length);
        assertEquals("Wrong path selected", stringPath.toString(), paths[0].toString());

        path = JTreeLocation.findMatchingPath(tree, stringPath2);
        tester.actionSelectRow(tree, new JTreeLocation(stringPath2));
        paths = tree.getSelectionPaths();
        assertTrue("Paths not visible", tree.isVisible(path));
        assertTrue("No paths selected", paths != null);
        assertEquals("Too many selected", 1, paths.length);
        assertEquals("Wrong path selected",
                     "[root, parent 2, child 1]", paths[0].toString());
    }

    public void testSelectRow() {
        int row = 1;
        showFrame(scrollPane);
        tester.actionSelectRow(tree, new JTreeLocation(row));
        TreePath[] paths = tree.getSelectionPaths();
        assertTrue("No paths selected", paths != null);
        assertEquals("Wrong row count selected", 1, paths.length);
        assertEquals("Wrong row selected", tree.getPathForRow(row), paths[0]);
    }

    public void testSelectInvisibleRow() {
        showFrame(scrollPane);
        try {
            tester.actionSelectRow(tree, new JTreeLocation(200));
            fail("Should not successfully select an unavailable row");
        }
        catch(ActionFailedException e) {
        }
    }

    public void testToggleRow() {
        int row = 2;
        showFrame(scrollPane);
        tester.actionToggleRow(tree, new JTreeLocation(row));
        assertTrue("Node should have expanded", tree.isExpanded(row));
        // Avoid the next action being interpreted as the same click
        tester.delay(500);
        tester.actionToggleRow(tree, new JTreeLocation(row));
        assertTrue("Node should not still be expanded", !tree.isExpanded(row));
    }

    public void testGetLocation() {
        showFrame(tree, new Dimension(200, 450));
        // position in expand control
        Rectangle rect = tree.getRowBounds(1);
        Point expansion = new Point(rect.x/2, rect.y + rect.height/2);
        tester.actionClick(tree, new JTreeLocation(expansion));
        assertTrue("Node should have expanded", tree.isExpanded(1));
        ComponentLocation loc = tester.getLocation(tree, expansion);
        Point where = loc.getPoint(tree);
        assertTrue("Row expansion click should designate row",
                   rect.contains(where));

        Point midRow = new Point(rect.x + rect.width/2,
                                 rect.y + rect.height/2);
        loc = tester.getLocation(tree, midRow);
        where = loc.getPoint(tree);
        assertTrue("Mid-row click should designate row",
                   rect.contains(where));

        rect = tree.getRowBounds(tree.getRowCount()-1);
        Point belowTree = new Point(rect.x + rect.width/2,
                                    rect.y + rect.height + 10);
        loc = tester.getLocation(tree, belowTree);
        where = loc.getPoint(tree);
        assertEquals("Point outside tree should store raw point",
                     belowTree, where);
    }

    static int count = 0;
    public void testConvertPathToStringPath() {
        class Foo { }
        DefaultMutableTreeNode root = new DefaultMutableTreeNode(new Foo());
        DefaultMutableTreeNode parent = new DefaultMutableTreeNode(new Foo());
        DefaultMutableTreeNode child = new DefaultMutableTreeNode(new Foo());
        root.add(parent);
        parent.add(child);
        JTree tree = new JTree(root);
        TreePath path = new TreePath(new Object[] { root, parent, child });
        TreePath strPath = JTreeTester.pathToStringPath(tree, path);
        assertNull("Should not use default toString() value as path: "
                   + strPath, strPath);

        count = 0;
        class Bar {
            private int id = count++;
            public String toString() { return String.valueOf(id); }
        }
        root = new DefaultMutableTreeNode(new Bar());
        parent = new DefaultMutableTreeNode(new Bar());
        child = new DefaultMutableTreeNode(new Bar());
        root.add(parent);
        parent.add(child);
        tree = new JTree(root);
        showFrame(new JScrollPane(tree));
        path = new TreePath(new Object[] { root, parent, child });
        assertEquals("Path should be stringifiable",
                     "[0, 1, 2]",
                     JTreeTester.pathToStringPath(tree, path).toString());
    }

    public void testAssertPathExists() {
        TreePath path = new TreePath(new String[] {
            "root", "parent 3", "child 1",
        });
        assertTrue("Path should exist",
                   tester.assertPathExists(tree, path));
        path = new TreePath(new String[] {
            "root", "parent 2", "child y",
        });
        assertFalse("Path should not exist",
                    tester.assertPathExists(tree, path));
    }

    /** Create a new test case with the given name. */
    public JTreeTesterTest(String name) {
        super(name);
    }

    public static void main(String[] args) {
        RepeatHelper.runTests(args, JTreeTesterTest.class);
    }
}

