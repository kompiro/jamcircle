package abbot.tester;

import java.awt.event.*;
import java.util.Vector;

import javax.swing.JComboBox;

import junit.extensions.abbot.*;

/** Unit test to verify supported JComboBox operations.<p> */

public class JComboBoxTesterTest extends ComponentTestFixture {

    private JComboBoxTester tester;
    private JComboBox box;
    private Vector list;
    private static final int MAX_ENTRIES = 100;

    /** Create a new test case with the given name. */
    public JComboBoxTesterTest(String name) {
        super(name);
    }

    private volatile String selectedItem;
    private volatile int selectedIndex;
    protected void setUp() {
        tester = (JComboBoxTester)ComponentTester.getTester(JComboBox.class);
        list = new Vector();
        for (int i=0;i < MAX_ENTRIES;i++) {
            list.add("item " + i);
        }
        box = new JComboBox(list);
        box.setSelectedIndex(-1);
        box.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ev) {
                JComboBox cb = (JComboBox)ev.getSource();
                selectedItem = (String)cb.getSelectedItem();
                selectedIndex = cb.getSelectedIndex();
            }
        });
    }

    // FIXME: occasionally see failures on OSX
    // (selected index = -1 @ 50, -1 @ 80)
    public void testSelectIndex() {
        showFrame(box);
        for (int i=0;i < MAX_ENTRIES;i += MAX_ENTRIES / 10) {
            selectedIndex = -1;
            tester.actionSelectIndex(box, i);
            assertEquals("Wrong index selected", i, selectedIndex);
        }
    }

    public void testSelectItem() {
        showFrame(box);
        for (int i=0;i < MAX_ENTRIES;i += MAX_ENTRIES / 10) {
            selectedItem = null;
            String item = "item " + i;
            tester.actionSelectItem(box, item);
            assertEquals("Wrong item selected", item, selectedItem);
        }
    }

    public void testSelectIndexEditable() {
        box.setEditable(true);
        showFrame(box);
        for (int i=0;i < MAX_ENTRIES;i += MAX_ENTRIES / 10) {
            selectedIndex = -1;
            tester.actionSelectIndex(box, i);
            assertEquals("Wrong index selected (editable)", i, selectedIndex);
        }
    }

    public void testSelectItemEditable() {
        box.setEditable(true);
        showFrame(box);
        for (int i=0;i < MAX_ENTRIES;i += MAX_ENTRIES / 10) {
            selectedItem = null;
            String item = "item " + i;
            tester.actionSelectItem(box, item);
            assertEquals("Wrong item selected (editable)", item, selectedItem);
        }
    }

    public static void main(String[] args) {
        RepeatHelper.runTests(args, JComboBoxTesterTest.class);
    }
}
