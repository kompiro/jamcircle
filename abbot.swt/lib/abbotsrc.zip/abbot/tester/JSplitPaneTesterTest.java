package abbot.tester;

import javax.swing.*;

import junit.extensions.abbot.*;

/** Unit test to verify the JSplitPaneTester class.<p> */

public class JSplitPaneTesterTest extends ComponentTestFixture {

    private JSplitPaneTester tester;
    private JSplitPane h, v;
    protected void setUp() {
        tester = new JSplitPaneTester();
        h = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        h.add(new JTree());
        h.add(new JTree());
        v = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        v.add(new JTree());
        v.add(new JTree());
        JPanel p = new JPanel();
        p.add(h);
        p.add(v);
        showFrame(p);
    }

    public void testMoveDividerVerticalMax() {
        tester.actionMoveDivider(h, 1.0);
        assertEquals("Vertical divider should be moved to max position",
                     h.getMaximumDividerLocation(),
                     h.getDividerLocation());
    }

    public void testMoveDividerHorizontalMax() {
        tester.actionMoveDivider(v, 1.0);
        assertEquals("Horizontal divider should be moved to max position",
                     v.getMaximumDividerLocation(),
                     v.getDividerLocation());
    }

    public void testMoveDividerVerticalCenter() {
        tester.actionMoveDivider(h, 0.5);
        int mid = h.getMaximumDividerLocation()/2;
        assertEquals("Vertical divider should be moved to center: "
                     + h.getDividerLocation() + "/" 
                     + h.getMaximumDividerLocation(),
                     mid, h.getDividerLocation());
    }

    public void testMoveDividerHorizontalCenter() {
        tester.actionMoveDivider(v, 0.5);
        int mid = v.getMaximumDividerLocation()/2;
        assertEquals("Horizontal divider should be moved to center: "
                     + v.getDividerLocation() + "/"
                     + v.getMaximumDividerLocation(),
                     mid, v.getDividerLocation());
    }

    public void testMoveDividerVerticalMin() {
        tester.actionMoveDivider(h, 1.0);
        tester.actionMoveDivider(h, 0.0);
        assertEquals("Vertical divider should be moved to min position",
                     h.getMinimumDividerLocation(), h.getDividerLocation());
    }

    public void testMoveDividerHorizontalMin() {
        tester.actionMoveDivider(v, 1.0);
        tester.actionMoveDivider(v, 0.0);
        assertEquals("Horizontal divider should be moved to min position",
                     v.getMinimumDividerLocation(), v.getDividerLocation());
    }

    public static void main(String[] args) {
        RepeatHelper.runTests(args, JSplitPaneTesterTest.class);
    }
}

