package abbot.tester;

import java.awt.Dimension;
import java.util.Vector;

import javax.swing.*;

import junit.extensions.abbot.*;

/** Unit test to verify the JTableTester class.<p> */

public class JTableTesterTest extends ComponentTestFixture {

    private int ROWS = 4;
    private int COLS = 4;
    private JTableTester tester;
    private JTable table;

    /** Create a new test case with the given name. */
    public JTableTesterTest(String name) {
        super(name);
    }

    protected void setUp() {
        String[][] data = new String[][] {
            { "0 one", "0 two", "0 three", "0 four" },
            { "1 one", "1 two", "1 three", "1 four" },
            { "2 one", "2 two", "2 three", "2 four" },
            { "3 one", "3 two", "3 three", "3 four" },
        };
        String[] names = { "one", "two", "three", "four" };
        table = new JTable(data, names);
        tester = new JTableTester();
    }

    public void testSelectCells() {
        showFrame(table);
        for (int row=0;row < ROWS;row++) {
            for (int col=0;col < COLS;col++) {
                tester.actionClick(table, new JTableLocation(row, col));
                assertEquals("Wrong row selected", row, 
                             table.getSelectedRow());
                assertEquals("Wrong column selected", col, 
                             table.getSelectedColumn());
            }
        }
    }

    /** Ensure scrolling works. */
    public void testScrollToVisible()
    {
        Vector data = new Vector();
        Vector columnNames = new Vector();

        int ROWS = 100;
        int COLS = 4;
        for (int row=0;row < ROWS;row++) {
            Vector rowv = new Vector();
            for (int col=0;col < COLS;col++) {
                rowv.add(String.valueOf(row+1) + "," + String.valueOf(col+1));
            }
            data.add(rowv);
        }
        for (int col=0;col < COLS;col++) {
            columnNames.add(String.valueOf(col));
        }
        table = new JTable(data, columnNames);
        Dimension size = new Dimension(150, 50);
        table.setPreferredScrollableViewportSize(size); 
        JScrollPane scrollPane = new JScrollPane(table);
        showFrame(scrollPane);
        tester.actionClick(table, new JTableLocation(0, 0));
        assertEquals("Wrong row selected", 0, table.getSelectedRow());
        assertEquals("Wrong column selected", 0, table.getSelectedColumn());
        tester.actionClick(table, new JTableLocation(ROWS-1, COLS-1));
        assertEquals("Wrong row selected", ROWS-1, table.getSelectedRow());
        assertEquals("Wrong column selected", COLS-1, table.getSelectedColumn());
        tester.actionClick(table, new JTableLocation(ROWS-1, 0));
        assertEquals("Wrong row selected", ROWS-1, table.getSelectedRow());
        assertEquals("Wrong column selected", 0, table.getSelectedColumn());
        tester.actionClick(table, new JTableLocation(0, COLS-1));
        assertEquals("Wrong row selected", 0, table.getSelectedRow());
        assertEquals("Wrong column selected", COLS-1, table.getSelectedColumn());
        tester.actionClick(table, new JTableLocation(0, 0));
        assertEquals("Wrong row selected", 0, table.getSelectedRow());
        assertEquals("Wrong column selected", 0, table.getSelectedColumn());
    }
        
    public static void main(String[] args) {
        RepeatHelper.runTests(args, JTableTesterTest.class);
    }
}

